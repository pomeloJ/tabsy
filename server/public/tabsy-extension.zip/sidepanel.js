import {
  COLORS, hexToChromeColor,
  getAll, getById, save, remove, clearAll,
  getSettings, saveSettings, getConflicts,
  getAutoSync, setAutoSync,
  getFlows, getFlowById, saveFlow, removeFlow,
  getClientId,
  getTimezone, setTimezone, getDetectedTimezone,
  formatDateTimeShort
} from './lib/storage.js';
import { performSync, isSyncConfigured } from './lib/sync.js';
import { serverNow, getClockOffset } from './lib/api-client.js';
import { captureWindow, detectWorkspaceWindows } from './lib/capture.js';
import { threeWayMerge } from './lib/merge.js';
import { FlowRunner, RunState } from './lib/flow-runner.js';
import { createFlow, createBlock, BLOCK_TYPES, BLOCK_CATEGORIES, TRIGGER_TYPES } from './lib/flow-schema.js';
import { mountFlowEditor, unmountFlowEditor } from './flow-editor.js';
import { t, initLocale, setLocale, getLocale } from './lib/i18n.js';

const MARKER_BASE = chrome.runtime.getURL('marker.html');
function isMarkerUrl(url) { return url?.startsWith(MARKER_BASE); }
function buildMarkerUrl(id, name, color) {
  const p = new URLSearchParams({ id, name, color });
  return `${MARKER_BASE}?${p}`;
}
const viewMain = document.getElementById('view-main');
const viewFlow = document.getElementById('view-flow');

// --- DOM refs ---
const nameInput = document.getElementById('ws-name');
const colorPicker = document.getElementById('color-picker');
const saveBtn = document.getElementById('save-btn');
const saveAllBtn = document.getElementById('save-all-btn');
const wsList = document.getElementById('ws-list');
const clearAllBtn = document.getElementById('clear-all-btn');
const versionInfo = document.getElementById('version-info');
if (versionInfo) {
  const m = chrome.runtime.getManifest();
  versionInfo.textContent = `v${m.version_name || m.version}`;
  fetch(chrome.runtime.getURL('build-info.json'))
    .then(r => r.ok ? r.json() : null)
    .then(info => {
      if (!info) return;
      const date = info.builtAt ? info.builtAt.replace('T', ' ').replace('Z', ' UTC') : '';
      versionInfo.textContent = `v${info.version} · build ${info.hash} · ${date}`;
      versionInfo.title = 'Compare this hash across browsers to verify they run the same build';
    })
    .catch(() => {});
}
const currentWsLabel = document.getElementById('current-ws-label');
const currentWsMeta = document.getElementById('current-ws-meta');
const currentWsActions = document.getElementById('current-ws-actions');
const quickSaveBtn = document.getElementById('quick-save-btn');
const quickDeleteBtn = document.getElementById('quick-delete-btn');
const saveNewToggle = document.getElementById('save-new-toggle');
const saveNewArrow = document.getElementById('save-new-arrow');
const saveSection = document.getElementById('save-section');
const currentWsFlows = document.getElementById('current-ws-flows');
const currentWsNotes = document.getElementById('current-ws-notes');
const otherWsToggle = document.getElementById('other-ws-toggle');
const otherWsArrow = document.getElementById('other-ws-arrow');
const otherWsBody = document.getElementById('other-ws-body');
const otherWsTitle = document.getElementById('other-ws-title');

let selectedColor = COLORS[0].hex;
let currentWorkspaceData = null; // { id, name, color } of detected workspace
let _activeTabUrl = '';
let _activeTabId = null; // Chrome tab ID of the active tab
let _activeTabTitle = ''; // Live title of the active tab
let _chromeTabToWsTab = new Map(); // Chrome tab ID → workspace tab.id

function matchUrlPattern(pattern, url) {
  if (!pattern) return false;
  const escaped = pattern.replace(/([.+?^${}()|[\]\\])/g, '\\$1');
  const regex = new RegExp('^' + escaped.replace(/\*/g, '.*') + '$');
  return regex.test(url);
}

async function refreshActiveTabUrl() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    _activeTabUrl = tab?.url || '';
    _activeTabId = tab?.id ?? null;
    _activeTabTitle = tab?.title || '';
  } catch { _activeTabUrl = ''; _activeTabId = null; _activeTabTitle = ''; }
}

// --- Color picker ---
function initColorPicker() {
  colorPicker.innerHTML = COLORS.map(c =>
    `<div class="color-dot ${c.hex === selectedColor ? 'selected' : ''}"
          style="background:${c.hex}" data-hex="${c.hex}" title="${c.name}"></div>`
  ).join('');

  colorPicker.addEventListener('click', (e) => {
    const dot = e.target.closest('.color-dot');
    if (!dot) return;
    selectedColor = dot.dataset.hex;
    colorPicker.querySelectorAll('.color-dot').forEach(d => d.classList.remove('selected'));
    dot.classList.add('selected');
  });
}

// --- Save current window ---
async function saveCurrentWindow() {
  const name = nameInput.value.trim();
  if (!name) { nameInput.focus(); return; }

  saveBtn.disabled = true;
  try {
    const win = await chrome.windows.getCurrent();
    // If this window is an existing workspace, reuse its ID (update instead of create)
    const existingId = await detectCurrentWorkspaceId(win.id);
    const workspace = await captureWindow(win.id, name, selectedColor, existingId);
    await save(workspace);
    nameInput.value = '';
    await renderList();
    triggerAutoSync();
  } finally {
    saveBtn.disabled = false;
  }
}

// Detect the workspace ID for a given window (via marker tab)
async function detectCurrentWorkspaceId(windowId) {
  const tabs = await chrome.tabs.query({ windowId });
  const markerTab = tabs.find(t => isMarkerUrl(t.url));
  if (!markerTab || markerTab.groupId === -1) return null;

  try {
    const group = await chrome.tabGroups.get(markerTab.groupId);
    const wsName = group.title?.replace(/^📂\s*/, '') || '';
    const workspaces = await getAll();
    const ws = workspaces.find(w => w.name === wsName);
    return ws ? ws.id : null;
  } catch {
    return null;
  }
}

// --- Save all windows ---
async function saveAllWindows() {
  saveAllBtn.disabled = true;
  try {
    const windows = await chrome.windows.getAll({ windowTypes: ['normal'] });
    for (let i = 0; i < windows.length; i++) {
      const win = windows[i];
      const tabs = await chrome.tabs.query({ windowId: win.id });
      const realTabs = tabs.filter(t => !isMarkerUrl(t.url));
      if (realTabs.length === 0) continue;

      const name = `Window ${i + 1}`;
      const color = COLORS[i % COLORS.length].hex;
      const workspace = await captureWindow(win.id, name, color);
      await save(workspace);
    }
    await renderList();
    triggerAutoSync();
  } finally {
    saveAllBtn.disabled = false;
  }
}

// --- Restore workspace ---
async function restoreWorkspace(workspace) {
  const chromeColor = hexToChromeColor(workspace.color);

  // Create new window with a blank tab (will be removed later)
  const newWin = await chrome.windows.create({ focused: true });
  const defaultTabId = newWin.tabs[0].id;

  // Create marker tab first (with workspace info)
  const markerUrl = buildMarkerUrl(workspace.id, workspace.name, workspace.color);
  const markerTab = await chrome.tabs.create({
    windowId: newWin.id,
    url: markerUrl,
    active: false,
    index: 0
  });

  // Create all tabs — order: pinned, then grouped (by group order), then ungrouped
  const createdTabs = [];
  const groups = workspace.groups || [];
  const groupOrder = new Map(groups.map((g, i) => [g.groupId, i]));

  const pinnedTabs = workspace.tabs.filter(t => t.pinned);
  const normalTabs = workspace.tabs.filter(t => !t.pinned);

  // Separate grouped vs ungrouped, sort grouped tabs so same-group tabs are adjacent
  const groupedNormal = normalTabs.filter(t => t.groupId && groupOrder.has(t.groupId));
  const ungroupedNormal = normalTabs.filter(t => !t.groupId || !groupOrder.has(t.groupId));
  groupedNormal.sort((a, b) => groupOrder.get(a.groupId) - groupOrder.get(b.groupId));

  const orderedTabs = [...pinnedTabs, ...groupedNormal, ...ungroupedNormal];

  console.log('[restore] workspace.tabs order:', workspace.tabs.map(t => `${t.url}(${t.groupId || 'none'})`));
  console.log('[restore] orderedTabs:', orderedTabs.map(t => `${t.url}(${t.groupId || 'none'})`));

  for (const tab of orderedTabs) {
    const created = await chrome.tabs.create({
      windowId: newWin.id,
      url: tab.url,
      pinned: tab.pinned,
      active: false
    });
    createdTabs.push({ spec: tab, tabId: created.id });
  }

  console.log('[restore] createdTabs:', createdTabs.map(ct => `${ct.spec.url} → chromeId:${ct.tabId}`));

  // Create tab groups
  const groupMap = {}; // workspace groupId → chrome groupId
  for (const group of workspace.groups) {
    const tabIds = createdTabs
      .filter(ct => ct.spec.groupId === group.groupId)
      .map(ct => ct.tabId);
    if (tabIds.length === 0) continue;

    console.log(`[restore] grouping "${group.title}" (${group.groupId}): tabIds=`, tabIds);

    const chromeGroupId = await chrome.tabs.group({ tabIds, createProperties: { windowId: newWin.id } });
    await chrome.tabGroups.update(chromeGroupId, {
      title: group.title,
      color: group.color,
      collapsed: group.collapsed
    });
    groupMap[group.groupId] = chromeGroupId;

    // Log tab order after grouping
    const afterGroup = await Promise.all(tabIds.map(id => chrome.tabs.get(id)));
    console.log(`[restore] after group "${group.title}":`, afterGroup.map(t => `${t.url} idx:${t.index}`));

    // Enforce correct tab order within this group (grouping may rearrange tabs)
    if (tabIds.length > 1) {
      for (let i = 1; i < tabIds.length; i++) {
        const prevTab = await chrome.tabs.get(tabIds[i - 1]);
        console.log(`[restore] move tabId:${tabIds[i]} to index:${prevTab.index + 1} (after tabId:${tabIds[i - 1]} at idx:${prevTab.index})`);
        await chrome.tabs.move(tabIds[i], { index: prevTab.index + 1 });
      }
      // Log final order after move
      const afterMove = await Promise.all(tabIds.map(id => chrome.tabs.get(id)));
      console.log(`[restore] after move "${group.title}":`, afterMove.map(t => `${t.url} idx:${t.index}`));
    }
  }

  // Enforce correct order for ungrouped tabs
  const ungroupedCreated = createdTabs.filter(ct => !ct.spec.groupId || !groupOrder.has(ct.spec.groupId));
  if (ungroupedCreated.length > 1) {
    for (let i = 1; i < ungroupedCreated.length; i++) {
      const prevTab = await chrome.tabs.get(ungroupedCreated[i - 1].tabId);
      await chrome.tabs.move(ungroupedCreated[i].tabId, { index: prevTab.index + 1 });
    }
  }

  // Create marker group (collapsed, with workspace name)
  const markerGroupId = await chrome.tabs.group({
    tabIds: [markerTab.id],
    createProperties: { windowId: newWin.id }
  });
  await chrome.tabGroups.update(markerGroupId, {
    title: `📂 ${workspace.name}`,
    color: chromeColor,
    collapsed: true
  });

  // Move marker group to the front
  await chrome.tabGroups.move(markerGroupId, { index: 0 });

  // Remove the default blank tab
  try { await chrome.tabs.remove(defaultTabId); } catch { /* may already be closed */ }

  // Activate first non-marker tab
  if (createdTabs.length > 0) {
    await chrome.tabs.update(createdTabs[0].tabId, { active: true });
  }
}

// --- Detect current workspace ---
async function detectCurrentWorkspace() {
  try {
    const win = await chrome.windows.getCurrent();
    const tabs = await chrome.tabs.query({ windowId: win.id });
    const markerTab = tabs.find(t => isMarkerUrl(t.url));

    if (!markerTab || markerTab.groupId === -1) {
      currentWorkspaceData = null;
      currentWsLabel.textContent = t('noWorkspaceDetected');
      currentWsMeta.style.display = 'none';
      currentWsActions.style.display = 'none';
      currentWsFlows.style.display = 'none';
      currentWsNotes.style.display = 'none';
      // No workspace — show save section directly, hide toggle
      saveNewToggle.style.display = 'none';
      saveSection.classList.remove('collapsed');
      return;
    }

    const group = await chrome.tabGroups.get(markerTab.groupId);
    const wsName = group.title?.replace(/^📂\s*/, '') || 'Unknown';
    const workspaces = await getAll();
    const ws = workspaces.find(w => w.name === wsName);

    const groupColor = /^[a-z]+$/.test(group.color) ? group.color : 'grey';
    currentWsLabel.innerHTML = `<span style="color:${groupColor}">📂</span> ${escapeHtml(wsName)}`;

    if (ws) {
      currentWorkspaceData = { id: ws.id, name: ws.name, color: ws.color };

      // Ensure all workspace tabs have persistent IDs
      let tabsMigrated = false;
      for (let i = 0; i < (ws.tabs || []).length; i++) {
        if (!ws.tabs[i].id) {
          ws.tabs[i].id = 't-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6) + '-' + i;
          tabsMigrated = true;
        }
      }
      if (tabsMigrated) await save(ws);

      const realTabs = tabs.filter(t => !isMarkerUrl(t.url) && (markerTab.groupId === -1 || t.groupId !== markerTab.groupId));

      // Build Chrome tab ID → workspace tab ID mapping
      const newMap = new Map();
      const usedWsTabIds = new Set();
      // First pass: match by _chromeTabId stored in workspace tabs (most reliable)
      for (const bt of realTabs) {
        const wsTab = (ws.tabs || []).find(wt => wt._chromeTabId === bt.id && !usedWsTabIds.has(wt.id));
        if (wsTab?.id) {
          newMap.set(bt.id, wsTab.id);
          usedWsTabIds.add(wsTab.id);
        }
      }
      // Second pass: keep existing runtime mappings
      for (const bt of realTabs) {
        if (newMap.has(bt.id)) continue;
        const existingWsTabId = _chromeTabToWsTab.get(bt.id);
        if (existingWsTabId && (ws.tabs || []).some(wt => wt.id === existingWsTabId && !usedWsTabIds.has(wt.id))) {
          newMap.set(bt.id, existingWsTabId);
          usedWsTabIds.add(existingWsTabId);
        }
      }
      // Third pass: match remaining by URL
      for (const bt of realTabs) {
        if (newMap.has(bt.id)) continue;
        const wsTab = (ws.tabs || []).find(wt => wt.url === bt.url && !usedWsTabIds.has(wt.id));
        if (wsTab?.id) {
          newMap.set(bt.id, wsTab.id);
          usedWsTabIds.add(wsTab.id);
        }
      }
      _chromeTabToWsTab = newMap;
      console.log('[mapping] built mapping:', [...newMap.entries()].map(([k,v]) => `chrome:${k}→ws:${v}`).join(', '));

      currentWsMeta.innerHTML = `${realTabs.length} tabs · ${formatTime(ws.savedAt, { liveAttr: true })}`;
      currentWsMeta.style.display = 'block';
      currentWsActions.style.display = 'flex';
      // In a workspace — show collapsible toggle, collapse save section by default
      saveNewToggle.style.display = 'flex';
      saveSection.classList.add('collapsed');
      saveNewArrow.classList.remove('open');
      // Render current workspace flows and notes
      renderCurrentWsFlows(ws);
      renderCurrentWsNotes(ws);
    } else {
      currentWorkspaceData = null;
      currentWsMeta.style.display = 'none';
      currentWsActions.style.display = 'none';
      currentWsFlows.style.display = 'none';
      currentWsNotes.style.display = 'none';
      saveNewToggle.style.display = 'none';
      saveSection.classList.remove('collapsed');
    }
  } catch {
    currentWorkspaceData = null;
    currentWsLabel.textContent = t('noWorkspaceDetected');
    currentWsMeta.style.display = 'none';
    currentWsActions.style.display = 'none';
    currentWsFlows.style.display = 'none';
    currentWsNotes.style.display = 'none';
    saveNewToggle.style.display = 'none';
    saveSection.classList.remove('collapsed');
  }
}

// --- Quick save current workspace ---
async function quickSaveCurrentWorkspace() {
  if (!currentWorkspaceData) return;
  quickSaveBtn.disabled = true;
  try {
    const win = await chrome.windows.getCurrent();
    const workspace = await captureWindow(win.id, currentWorkspaceData.name, currentWorkspaceData.color, currentWorkspaceData.id);
    await save(workspace);
    await renderList();
    await detectCurrentWorkspace();
    triggerAutoSync();
  } finally {
    quickSaveBtn.disabled = false;
  }
}

// --- Quick delete current workspace ---
async function quickDeleteCurrentWorkspace() {
  if (!currentWorkspaceData) return;
  if (!confirm(t('deleteConfirm', { name: currentWorkspaceData.name }))) return;
  quickDeleteBtn.disabled = true;
  try {
    await remove(currentWorkspaceData.id);
    currentWorkspaceData = null;
    await renderList();
    await detectCurrentWorkspace();
    triggerAutoSync();
  } finally {
    quickDeleteBtn.disabled = false;
  }
}

// --- Render current workspace flows (expanded, prominent) ---

function renderCurrentWsFlows(ws) {
  const flows = ws.flows || [];
  const triggerLabel = (t) => TRIGGER_TYPES[t]?.label || t;

  let html = `<div class="flow-list-header">
    <span>${t('flows')}${flows.length ? ` (${flows.length})` : ''}</span>
    <button class="btn btn-sm btn-secondary" data-add-flow="${ws.id}">${t('newFlow')}</button>
  </div>`;

  if (flows.length > 0) {
    html += flows.map(f => {
      const urlMatched = f.enabled && f.trigger !== 'manual' && f.match && _activeTabUrl && matchUrlPattern(f.match, _activeTabUrl);
      return `
      <div class="flow-item ${f.enabled ? '' : 'disabled'}">
        <span class="flow-item-name" data-edit-flow="${f.id}" data-ws="${ws.id}">${escapeHtml(f.name)}</span>
        ${urlMatched ? `<span class="flow-match-badge" title="Matches current tab">&#9889; ${t('match')}</span>` : ''}
        <span class="flow-item-trigger ${f.trigger}">${triggerLabel(f.trigger)}</span>
        <span class="flow-item-actions">
          <button class="flow-item-btn run" data-run-flow="${f.id}" data-ws="${ws.id}" title="${t('run')}">&#9654;</button>
          <button class="flow-item-btn edit" data-edit-flow="${f.id}" data-ws="${ws.id}" title="${t('edit')}">&#9998;</button>
          <button class="flow-item-btn dup" data-dup-flow="${f.id}" data-ws="${ws.id}" title="${t('duplicate')}">&#10063;</button>
          <button class="flow-item-btn delete" data-del-flow="${f.id}" data-ws="${ws.id}" title="${t('delete')}">&times;</button>
        </span>
      </div>`;
    }).join('');
  }

  currentWsFlows.innerHTML = html;
  currentWsFlows.style.display = 'block';
}

// Event delegation for current-ws flows area
currentWsFlows.addEventListener('click', async (e) => {
  const target = e.target.closest('[data-edit-flow], [data-run-flow], [data-dup-flow], [data-del-flow], [data-add-flow]');
  if (!target) return;

  if (target.dataset.dupFlow) {
    e.stopPropagation();
    await duplicateFlow(target.dataset.ws, target.dataset.dupFlow);
    await renderList();
    await detectCurrentWorkspace();
  } else if (target.dataset.editFlow) {
    e.stopPropagation();
    openFlowEditor(target.dataset.ws, target.dataset.editFlow);
  } else if (target.dataset.runFlow) {
    e.stopPropagation();
    runFlowOnActiveTab(target.dataset.ws, target.dataset.runFlow);
  } else if (target.dataset.delFlow) {
    e.stopPropagation();
    if (!confirm(t('deleteFlowConfirm'))) return;
    await removeFlow(target.dataset.ws, target.dataset.delFlow);
    await renderList();
    await detectCurrentWorkspace();
  } else if (target.dataset.addFlow) {
    addNewFlow(target.dataset.addFlow);
  }
});

// Double-click rename for current workspace name
currentWsLabel.addEventListener('dblclick', async () => {
  if (!currentWorkspaceData) return;
  const oldName = currentWorkspaceData.name;
  const input = document.createElement('input');
  input.type = 'text';
  input.value = oldName;
  input.style.cssText = 'width:100%;font-size:14px;font-weight:600;padding:2px 4px;border:1px solid var(--primary);border-radius:3px;outline:none;';
  currentWsLabel.textContent = '';
  currentWsLabel.appendChild(input);
  input.focus();
  input.select();

  const finish = async () => {
    const newName = input.value.trim();
    if (newName && newName !== oldName) {
      const ws = await getById(currentWorkspaceData.id);
      if (ws) {
        ws.name = newName;
        ws.savedAt = new Date().toISOString();
        ws.syncStatus = ws.syncStatus === 'synced' ? 'pending' : ws.syncStatus;
        await save(ws);
        currentWorkspaceData.name = newName;
        // Update Chrome tab group title
        try {
          const win = await chrome.windows.getCurrent({ populate: true });
          const markerTab = win.tabs.find(t => isMarkerUrl(t.url));
          if (markerTab && markerTab.groupId !== -1) {
            await chrome.tabGroups.update(markerTab.groupId, { title: `📂 ${newName}` });
          }
        } catch {}
        triggerAutoSync();
      }
    }
    await detectCurrentWorkspace();
    await renderList();
  };

  input.addEventListener('blur', finish);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); input.blur(); }
    if (e.key === 'Escape') { input.value = oldName; input.blur(); }
  });
});

// Double-click rename for workspace cards in list
wsList.addEventListener('dblclick', async (e) => {
  const nameEl = e.target.closest('.ws-card-name');
  if (!nameEl) return;
  const card = nameEl.closest('.ws-card');
  if (!card) return;
  const wsId = card.dataset.id;
  const ws = await getById(wsId);
  if (!ws) return;

  const oldName = ws.name;
  const input = document.createElement('input');
  input.type = 'text';
  input.value = oldName;
  input.style.cssText = 'width:100%;font-size:12px;padding:2px 4px;border:1px solid var(--primary);border-radius:3px;outline:none;';
  nameEl.textContent = '';
  nameEl.appendChild(input);
  input.focus();
  input.select();

  const finish = async () => {
    const newName = input.value.trim();
    if (newName && newName !== oldName) {
      ws.name = newName;
      ws.savedAt = new Date().toISOString();
      ws.syncStatus = ws.syncStatus === 'synced' ? 'pending' : ws.syncStatus;
      await save(ws);
      triggerAutoSync();
    }
    await renderList();
  };

  input.addEventListener('blur', finish);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); input.blur(); }
    if (e.key === 'Escape') { input.value = oldName; input.blur(); }
  });
});

// Double-click rename for current-ws flows
currentWsFlows.addEventListener('dblclick', (e) => {
  const el = e.target.closest('[data-edit-flow]');
  if (!el) return;
  e.stopPropagation();
  startRenameFlow(el, el.dataset.ws, el.dataset.editFlow);
});

// --- Render current workspace notes (collapsible) ---
let _notesCollapsed = false;

function renderCurrentWsNotes(ws) {
  const notes = ws.notes || [];
  const groups = ws.groups || [];
  const tabs = ws.tabs || [];

  // Migrate old url-based tab links to tabId-based
  let migrated = false;
  for (const note of notes) {
    for (const link of (note.links || [])) {
      if (link.type === 'tab' && link.url && !link.tabId) {
        const tab = tabs.find(t => t.url === link.url);
        if (tab?.id) {
          link.tabId = tab.id;
          delete link.url;
          migrated = true;
        }
      }
    }
  }
  if (migrated) save(ws);

  // Helper: find notes linked to a target
  const notesFor = (type, id) => notes.filter(n => n.links?.some(l =>
    type === 'workspace' ? l.type === 'workspace' :
    type === 'group' ? (l.type === 'group' && l.groupId === id) :
    type === 'tab' ? (l.type === 'tab' && l.tabId === id) : false
  ));

  const notePreview = (noteList) => {
    if (noteList.length === 0) return '';
    return noteList.map(n => {
      const preview = n.content.length > 60 ? n.content.slice(0, 60) + '…' : n.content;
      return `<div class="notes-tree-note" data-note-id="${n.id}">${escapeHtml(preview)}</div>`;
    }).join('');
  };

  // Resolve active tab → workspace tab via Chrome tab ID mapping
  const activeWsTabId = _activeTabId != null ? _chromeTabToWsTab.get(_activeTabId) : null;
  const activeTab = activeWsTabId ? tabs.find(t => t.id === activeWsTabId) : null;
  const activeTabNotes = activeTab ? notesFor('tab', activeTab.id) : [];
  console.log('[notes] chromeTabId:', _activeTabId, '→ wsTabId:', activeWsTabId, '→ activeTab:', activeTab?.title, '| mapping size:', _chromeTabToWsTab.size, '| notes:', activeTabNotes.length);

  let html = '';

  // === Active tab notes — pinned at top ===
  html += `<div class="notes-active-tab">`;
  html += `<div class="notes-active-header">
    <span class="note-item-icon">📄</span>
    <span class="notes-active-label">${activeTab ? escapeHtml(_activeTabTitle || _activeTabUrl || activeTab.title || activeTab.url) : t('noActiveTab')}</span>
    ${activeTab ? `<button class="note-tree-add" data-add-for="tab" data-tab-id="${activeTab.id}">+</button>` : ''}
  </div>`;
  if (activeTabNotes.length > 0) {
    html += activeTabNotes.map(n => {
      const lines = n.content.split('\n').slice(0, 10).join('\n');
      const preview = lines.length > 500 ? lines.slice(0, 500) + '…' : lines;
      return `<div class="notes-active-note" data-note-id="${n.id}">${escapeHtml(preview)}</div>`;
    }).join('');
  } else if (activeTab) {
    html += `<div class="notes-active-empty">${t('noNotes')} <button class="note-tree-add" data-add-for="tab" data-tab-id="${activeTab.id}">+</button></div>`;
  }
  html += `</div>`;

  // === Collapsible tree for all notes ===
  html += `<div class="notes-section-header" id="notes-toggle">
    <span>${t('notes')}${notes.length ? ` (${notes.length})` : ''}</span>
    <span class="arrow ${_notesCollapsed ? '' : 'open'}">&#9654;</span>
  </div>`;
  html += `<div class="notes-list ${_notesCollapsed ? 'collapsed' : ''}">`;

  // Workspace
  const wsNotes = notesFor('workspace');
  html += `<div class="note-tree-item">
    <div class="note-tree-row">
      <span class="note-item-icon">📂</span>
      <span class="note-item-label">${escapeHtml(ws.name)}</span>
      <button class="note-tree-add" data-add-for="workspace">+</button>
    </div>
    ${notePreview(wsNotes)}
  </div>`;

  // Groups
  for (const g of groups) {
    const gNotes = notesFor('group', g.groupId);
    html += `<div class="note-tree-item">
      <div class="note-tree-row">
        <span class="note-item-icon">📁</span>
        <span class="note-item-label">${escapeHtml(g.title || t('untitled'))}</span>
        <button class="note-tree-add" data-add-for="group" data-gid="${g.groupId}">+</button>
      </div>
      ${notePreview(gNotes)}
    </div>`;
  }

  // Determine which workspace tab IDs are currently open in the browser
  const openWsTabIds = new Set(_chromeTabToWsTab.values());

  // Open tabs (skip active, already shown at top)
  for (const tab of tabs) {
    if (tab.id === activeWsTabId) continue;
    if (!openWsTabIds.has(tab.id)) continue; // closed tabs handled below
    const tNotes = notesFor('tab', tab.id);
    html += `<div class="note-tree-item">
      <div class="note-tree-row">
        <span class="note-item-icon">📄</span>
        <span class="note-item-label">${escapeHtml(tab.title || tab.url)}</span>
        <button class="note-tree-add" data-add-for="tab" data-tab-id="${tab.id}">+</button>
      </div>
      ${notePreview(tNotes)}
    </div>`;
  }

  // Uncategorized: notes linked only to closed tabs or missing groups (not shown elsewhere)
  const existingGroupIds = new Set(groups.map(g => g.groupId));
  const isVisibleLink = l =>
    l.type === 'workspace' ||
    (l.type === 'group' && existingGroupIds.has(l.groupId)) ||
    (l.type === 'tab' && (openWsTabIds.has(l.tabId) || l.tabId === activeWsTabId));
  const uncategorizedNotes = notes.filter(n =>
    n.links?.length > 0 &&
    !n.links.some(isVisibleLink)
  );
  if (uncategorizedNotes.length > 0) {
    html += `<div class="note-tree-item unlinked">
      <div class="note-tree-row"><span class="note-item-icon">📋</span><span class="note-item-label" style="opacity:0.6">${t('uncategorized') || 'Uncategorized'} (${uncategorizedNotes.length})</span></div>
      ${notePreview(uncategorizedNotes)}
    </div>`;
  }

  // Unlinked notes
  const linkedIds = new Set();
  notes.forEach(n => { if (n.links?.length > 0) linkedIds.add(n.id); });
  const unlinked = notes.filter(n => !n.links || n.links.length === 0);
  if (unlinked.length > 0) {
    html += `<div class="note-tree-item unlinked">
      <div class="note-tree-row"><span class="note-item-icon">📌</span><span class="note-item-label" style="opacity:0.6">${t('unlinked') || 'Unlinked'}</span></div>
      ${notePreview(unlinked)}
    </div>`;
  }

  html += '</div>';
  currentWsNotes.innerHTML = html;
  currentWsNotes.style.display = 'block';

  // Toggle collapse
  currentWsNotes.querySelector('#notes-toggle')?.addEventListener('click', () => {
    _notesCollapsed = !_notesCollapsed;
    const arrow = currentWsNotes.querySelector('.arrow');
    arrow.classList.toggle('open', !_notesCollapsed);
    currentWsNotes.querySelector('.notes-list').classList.toggle('collapsed', _notesCollapsed);
  });

  // Click note to edit (both tree notes and active tab notes)
  currentWsNotes.querySelectorAll('.notes-tree-note, .notes-active-note').forEach(el => {
    el.addEventListener('click', () => {
      openNoteEditor(ws, el.dataset.noteId);
    });
  });

  // Add note for item
  currentWsNotes.querySelectorAll('.note-tree-add').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const forType = btn.dataset.addFor;
      const link = forType === 'workspace' ? { type: 'workspace' } :
                   forType === 'group' ? { type: 'group', groupId: btn.dataset.gid } :
                   { type: 'tab', tabId: btn.dataset.tabId };
      const note = { id: 'n-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6), content: '', links: [link], createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
      if (!ws.notes) ws.notes = [];
      ws.notes.push(note);
      ws.savedAt = new Date().toISOString();
      ws.syncStatus = ws.syncStatus === 'local_only' ? 'local_only' : 'pending';
      save(ws).then(() => {
        openNoteEditor(ws, note.id);
        renderCurrentWsNotes(ws);
      });
    });
  });
}

function openNoteEditor(ws, noteId) {
  const note = (ws.notes || []).find(n => n.id === noteId);
  if (!note) return;

  const overlay = document.createElement('div');
  overlay.className = 'notes-edit-overlay';

  // Build link label
  const linkLabels = (note.links || []).map(l => {
    if (l.type === 'workspace') return `📂 ${ws.name}`;
    if (l.type === 'group') { const g = (ws.groups || []).find(g => g.groupId === l.groupId); return `📁 ${g ? g.title : l.groupId}`; }
    if (l.type === 'tab') { const tab = (ws.tabs || []).find(t => t.id === l.tabId); return `📄 ${tab ? (tab.title || tab.url) : l.tabId}`; }
    return '?';
  });

  overlay.innerHTML = `
    <div class="notes-edit-header">
      <button class="back-btn">&larr;</button>
      <span class="title">${t('editNote') || 'Edit Note'}</span>
    </div>
    <div class="notes-edit-links">${linkLabels.map(l => `<span class="note-edit-link-chip">${escapeHtml(l)}</span>`).join('')}</div>
    <div class="notes-edit-body">
      <textarea maxlength="2000" placeholder="${t('notesPlaceholder')}">${escapeHtml(note.content)}</textarea>
    </div>
    <div class="notes-edit-footer"><span class="char-count">${note.content.length} / 2000</span></div>
  `;
  document.body.appendChild(overlay);

  const textarea = overlay.querySelector('textarea');
  const charCount = overlay.querySelector('.char-count');
  textarea.focus();

  textarea.addEventListener('input', () => {
    charCount.textContent = `${textarea.value.length} / 2000`;
  });

  const close = async () => {
    const newText = textarea.value;
    if (newText !== note.content) {
      note.content = newText;
      note.updatedAt = new Date().toISOString();
      ws.savedAt = new Date().toISOString();
      ws.syncStatus = ws.syncStatus === 'local_only' ? 'local_only' : 'pending';
      await save(ws);
      renderCurrentWsNotes(ws);
    }
    overlay.remove();
  };

  overlay.querySelector('.back-btn').addEventListener('click', close);
}

// --- Render workspace list (differential) ---

// Cache of last-rendered card HTML keyed by workspace id
let _renderedCards = new Map();
let _renderedOrder = []; // ordered workspace ids from last render

function buildCardHtml(w, wsFlows) {
  return `
      <div class="ws-card-header">
        <div class="ws-card-dot" style="background:${safeColor(w.color)}"></div>
        <div class="ws-card-name">${escapeHtml(w.name)}${(w.notes || []).length > 0 ? ` <span class="ws-card-notes-badge">📝</span>` : ''}</div>
        ${syncBadge(w.syncStatus)}
      </div>
      <div class="ws-card-meta">
        ${w.tabs.length} tab${w.tabs.length !== 1 ? 's' : ''} · ${w.groups.length} group${w.groups.length !== 1 ? 's' : ''} · ${formatTime(w.savedAt, { liveAttr: true })}
      </div>
      ${renderConflictSection(w)}
      ${renderFlowChips(w.id, wsFlows)}
      <div class="ws-card-actions">
        <button class="btn btn-primary btn-sm" data-restore="${w.id}">${t('restore')}</button>
        <button class="btn btn-secondary btn-sm" data-notes="${w.id}"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg></button>
        <button class="btn btn-danger btn-sm" data-delete="${w.id}">${t('delete')}</button>
      </div>`;
}

async function renderList() {
  const allWorkspaces = await getAll();

  // Separate current workspace from others
  const currentId = currentWorkspaceData?.id;
  const workspaces = allWorkspaces.filter(w => w.id !== currentId);

  // Update other-ws toggle title
  const sectionLabel = currentId ? t('otherWorkspaces') : t('savedWorkspaces');
  otherWsTitle.textContent = workspaces.length > 0
    ? `${sectionLabel} (${workspaces.length})`
    : sectionLabel;

  if (workspaces.length === 0) {
    wsList.innerHTML = currentId
      ? `<div class="empty-state">${t('noOtherWorkspaces')}</div>`
      : `<div class="empty-state">${t('noSavedWorkspaces')}</div>`;
    _renderedCards.clear();
    _renderedOrder = [];
    return;
  }

  // Sort by savedAt descending
  workspaces.sort((a, b) => new Date(b.savedAt) - new Date(a.savedAt));

  // Build flows map from cached data (getFlows uses cached getAll internally)
  const allFlows = await getFlows();

  const newOrder = workspaces.map(w => w.id);
  const orderChanged = newOrder.length !== _renderedOrder.length ||
    newOrder.some((id, i) => id !== _renderedOrder[i]);

  // Build new card HTML map
  const newCards = new Map();
  for (const w of workspaces) {
    newCards.set(w.id, { html: buildCardHtml(w, allFlows[w.id]), color: w.color });
  }

  if (orderChanged) {
    // Order changed (added, removed, reordered) — rebuild DOM but reuse unchanged nodes
    const fragment = document.createDocumentFragment();
    for (const w of workspaces) {
      const card = newCards.get(w.id);
      const existing = wsList.querySelector(`.ws-card[data-id="${w.id}"]`);
      if (existing && _renderedCards.get(w.id)?.html === card.html) {
        // Reuse unchanged DOM node
        fragment.appendChild(existing);
      } else {
        // Create new card
        const el = document.createElement('div');
        el.className = 'ws-card';
        el.style.borderLeftColor = card.color;
        el.dataset.id = w.id;
        el.innerHTML = card.html;
        fragment.appendChild(el);
      }
    }
    wsList.innerHTML = '';
    wsList.appendChild(fragment);
  } else {
    // Same order — only patch changed cards in-place
    for (const w of workspaces) {
      const card = newCards.get(w.id);
      if (_renderedCards.get(w.id)?.html === card.html) continue;
      const el = wsList.querySelector(`.ws-card[data-id="${w.id}"]`);
      if (el) {
        el.style.borderLeftColor = card.color;
        el.innerHTML = card.html;
      }
    }
  }

  _renderedCards = newCards;
  _renderedOrder = newOrder;
}

// --- Event delegation on wsList (single listener, never re-attached) ---
wsList.addEventListener('click', async (e) => {
  const target = e.target.closest('[data-restore], [data-delete], [data-notes], [data-resolve], [data-edit-flow], [data-run-flow], [data-dup-flow], [data-del-flow], [data-add-flow]');
  if (!target) return;

  if (target.dataset.restore) {
    target.disabled = true;
    const ws = await getById(target.dataset.restore);
    if (ws) await restoreWorkspace(ws);
    target.disabled = false;
  } else if (target.dataset.delete) {
    const ws = await getById(target.dataset.delete);
    if (!confirm(t('deleteConfirm', { name: ws?.name }))) return;
    await remove(target.dataset.delete);
    await renderList();
    triggerAutoSync();
  } else if (target.dataset.notes) {
    const ws = await getById(target.dataset.notes);
    if (ws) {
      // Find or create a workspace-linked note
      const existing = (ws.notes || []).find(n => n.links?.some(l => l.type === 'workspace'));
      if (existing) {
        openNoteEditor(ws, existing.id);
      } else {
        const note = { id: 'n-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6), content: '', links: [{ type: 'workspace' }], createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
        if (!ws.notes) ws.notes = [];
        ws.notes.push(note);
        ws.savedAt = new Date().toISOString();
        ws.syncStatus = ws.syncStatus === 'local_only' ? 'local_only' : 'pending';
        await save(ws);
        openNoteEditor(ws, note.id);
      }
    }
  } else if (target.dataset.resolve) {
    target.disabled = true;
    await resolveConflict(target.dataset.resolve, target.dataset.action);
    target.disabled = false;
  } else if (target.dataset.dupFlow) {
    e.stopPropagation();
    await duplicateFlow(target.dataset.ws, target.dataset.dupFlow);
    await renderList();
  } else if (target.dataset.editFlow) {
    e.stopPropagation();
    openFlowEditor(target.dataset.ws, target.dataset.editFlow);
  } else if (target.dataset.runFlow) {
    e.stopPropagation();
    runFlowOnActiveTab(target.dataset.ws, target.dataset.runFlow);
  } else if (target.dataset.delFlow) {
    e.stopPropagation();
    if (!confirm(t('deleteFlowConfirm'))) return;
    await removeFlow(target.dataset.ws, target.dataset.delFlow);
    await renderList();
  } else if (target.dataset.addFlow) {
    addNewFlow(target.dataset.addFlow);
  }
});

// Double-click for flow rename (separate listener since dblclick doesn't bubble the same way)
wsList.addEventListener('dblclick', (e) => {
  const el = e.target.closest('[data-edit-flow]');
  if (!el) return;
  e.stopPropagation();
  startRenameFlow(el, el.dataset.ws, el.dataset.editFlow);
});

// --- Helpers ---
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function safeColor(color) {
  return /^#[0-9a-fA-F]{3,6}$/.test(color) ? color : '#69797e';
}

function getSyncLabels() {
  return {
    synced: t('syncedBadge'),
    local_only: t('localBadge'),
    pending: t('pendingBadge'),
    conflict: t('conflictBadge')
  };
}

function syncBadge(status) {
  if (!status) return '';
  const labels = getSyncLabels();
  const label = labels[status];
  if (!label) return '';
  return `<span class="ws-card-sync ${status}">${label}</span>`;
}

function formatTime(iso, { liveAttr = false } = {}) {
  const d = new Date(iso);
  if (isNaN(d)) return iso || '';
  const now = Date.now();
  const diffSec = Math.floor((now - d.getTime()) / 1000);
  if (diffSec < 0) return formatDateTimeShort(iso, _currentTz);
  if (diffSec < 60) {
    const text = `${diffSec}${t('secondsAgo')}`;
    return liveAttr ? `<span class="live-time" data-time="${iso}">${text}</span>` : text;
  }
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 10) return `${diffMin}${t('minutesAgo')}`;
  return formatDateTimeShort(iso, _currentTz);
}

// Live-update all .live-time elements every second
setInterval(() => {
  document.querySelectorAll('.live-time').forEach(el => {
    const iso = el.dataset.time;
    const d = new Date(iso);
    const diffSec = Math.floor((Date.now() - d.getTime()) / 1000);
    if (diffSec >= 60) {
      // Graduated past seconds — replace with static text
      const diffMin = Math.floor(diffSec / 60);
      if (diffMin < 10) {
        el.replaceWith(`${diffMin}${t('minutesAgo')}`);
      } else {
        el.replaceWith(formatDateTimeShort(iso, _currentTz));
      }
    } else {
      el.textContent = `${diffSec}${t('secondsAgo')}`;
    }
  });
}, 1000);

// --- Conflict UI ---

function renderConflictSection(workspace) {
  if (workspace.syncStatus !== 'conflict' || !workspace.conflictData) return '';
  const cd = workspace.conflictData;
  const localTabCount = cd.localVersion.tabs.length;
  const remoteTabCount = cd.remoteVersion.tabs.length;
  const conflictCount = cd.conflicts ? cd.conflicts.length : 0;

  const conflictDetail = conflictCount > 0
    ? (conflictCount > 1 ? t('tabConflictsPlural', { n: conflictCount }) : t('tabConflicts', { n: conflictCount }))
    : '';

  return `
    <div class="ws-conflict-section">
      <div class="conflict-summary">
        <span class="conflict-label">${t('syncConflict')}</span>
        <span class="conflict-detail">
          ${t('localLabel')}: ${localTabCount} tabs · ${t('remoteLabel')}: ${remoteTabCount} tabs${conflictDetail ? ` · ${conflictDetail}` : ''}
        </span>
      </div>
      <div class="conflict-actions">
        <button class="btn btn-sm btn-secondary" data-resolve="${workspace.id}" data-action="local">${t('keepLocal')}</button>
        <button class="btn btn-sm btn-secondary" data-resolve="${workspace.id}" data-action="remote">${t('keepRemote')}</button>
        <button class="btn btn-sm btn-primary" data-resolve="${workspace.id}" data-action="merge">${t('mergeAll')}</button>
      </div>
    </div>
  `;
}

async function resolveConflict(workspaceId, action) {
  const ws = await getById(workspaceId);
  if (!ws || !ws.conflictData) return;

  const cd = ws.conflictData;

  switch (action) {
    case 'local':
      ws.tabs = cd.localVersion.tabs;
      ws.groups = cd.localVersion.groups;
      ws.savedAt = serverNow();
      ws.syncStatus = 'pending';
      delete ws.conflictData;
      break;
    case 'remote':
      ws.tabs = cd.remoteVersion.tabs;
      ws.groups = cd.remoteVersion.groups;
      ws.savedAt = cd.remoteVersion.savedAt;
      ws.syncStatus = 'pending';
      delete ws.conflictData;
      break;
    case 'merge': {
      const base = ws.syncedSnapshot || { tabs: [], groups: [] };
      const result = threeWayMerge(base, cd.localVersion, cd.remoteVersion);
      ws.tabs = result.merged.tabs;
      ws.groups = result.merged.groups;
      ws.savedAt = serverNow();
      ws.syncStatus = 'pending';
      ws.syncedSnapshot = { tabs: result.merged.tabs, groups: result.merged.groups };
      delete ws.conflictData;
      break;
    }
  }

  await save(ws);
  await renderList();
  renderConflictBanner();
  triggerAutoSync();
}

const conflictBanner = document.getElementById('conflict-banner');

async function renderConflictBanner() {
  const conflicts = await getConflicts();
  if (conflicts.length === 0) {
    conflictBanner.style.display = 'none';
    return;
  }
  conflictBanner.style.display = 'flex';
  conflictBanner.innerHTML = conflicts.length > 1
    ? t('conflictBannerPlural', { n: conflicts.length })
    : t('conflictBanner', { n: conflicts.length });
}

// --- Event listeners ---
saveBtn.addEventListener('click', saveCurrentWindow);
saveAllBtn.addEventListener('click', saveAllWindows);
quickSaveBtn.addEventListener('click', quickSaveCurrentWorkspace);
quickDeleteBtn.addEventListener('click', quickDeleteCurrentWorkspace);
clearAllBtn.addEventListener('click', async () => {
  if (!confirm(t('deleteAllConfirm'))) return;
  await clearAll();
  await renderList();
  triggerAutoSync();
});

// Allow Enter key to save
nameInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') saveCurrentWindow();
});

// Collapsible save-new section
saveNewToggle.addEventListener('click', () => {
  saveSection.classList.toggle('collapsed');
  saveNewArrow.classList.toggle('open');
});

// Collapsible other-workspaces section
otherWsToggle.addEventListener('click', () => {
  otherWsBody.classList.toggle('collapsed');
  otherWsArrow.classList.toggle('open');
});

// --- Settings ---
const settingsToggle = document.getElementById('settings-toggle');
const settingsArrow = document.getElementById('settings-arrow');
const settingsPanel = document.getElementById('settings-panel');
const clientIdInput = document.getElementById('client-id');
const copyClientIdBtn = document.getElementById('copy-client-id-btn');
const serverUrlInput = document.getElementById('server-url');
const syncTokenInput = document.getElementById('sync-token');
const cfAccessToggle = document.getElementById('cf-access-toggle');
const cfAccessArrow = document.getElementById('cf-access-arrow');
const cfAccessPanel = document.getElementById('cf-access-panel');
const cfClientIdInput = document.getElementById('cf-client-id');
const cfClientSecretInput = document.getElementById('cf-client-secret');
const saveSettingsBtn = document.getElementById('save-settings-btn');
const testConnBtn = document.getElementById('test-conn-btn');
const settingsStatus = document.getElementById('settings-status');

cfAccessToggle.addEventListener('click', () => {
  const open = cfAccessPanel.style.display === 'none';
  cfAccessPanel.style.display = open ? 'block' : 'none';
  cfAccessArrow.style.transform = open ? 'rotate(90deg)' : '';
});

// Load and display client ID
getClientId().then(id => { clientIdInput.value = id; });
copyClientIdBtn.addEventListener('click', () => {
  navigator.clipboard.writeText(clientIdInput.value).then(() => {
    const orig = copyClientIdBtn.textContent;
    copyClientIdBtn.textContent = t('copied') || 'Copied';
    setTimeout(() => { copyClientIdBtn.textContent = orig; }, 1500);
  });
});

settingsToggle.addEventListener('click', () => {
  settingsPanel.classList.toggle('open');
  settingsArrow.classList.toggle('open');
});

saveSettingsBtn.addEventListener('click', async () => {
  const serverUrl = serverUrlInput.value.trim().replace(/\/+$/, '');
  const token = syncTokenInput.value.trim();
  const cfAccessClientId = cfClientIdInput.value.trim();
  const cfAccessClientSecret = cfClientSecretInput.value.trim();
  await saveSettings({ serverUrl, token, cfAccessClientId, cfAccessClientSecret });
  settingsStatus.textContent = t('settingsSaved');
  settingsStatus.className = 'settings-status ok';
});

testConnBtn.addEventListener('click', async () => {
  const serverUrl = serverUrlInput.value.trim().replace(/\/+$/, '');
  const token = syncTokenInput.value.trim();

  if (!serverUrl) {
    settingsStatus.textContent = t('enterServerUrl');
    settingsStatus.className = 'settings-status err';
    return;
  }

  testConnBtn.disabled = true;
  settingsStatus.textContent = t('testing');
  settingsStatus.className = 'settings-status';

  try {
    // Build CF Access headers if configured
    const cfId = cfClientIdInput.value.trim();
    const cfSecret = cfClientSecretInput.value.trim();
    const cfHeaders = {};
    if (cfId && cfSecret) {
      cfHeaders['CF-Access-Client-Id'] = cfId;
      cfHeaders['CF-Access-Client-Secret'] = cfSecret;
    }

    // Test health endpoint
    const healthRes = await fetch(`${serverUrl}/api/health`, { headers: cfHeaders });
    if (!healthRes.ok) throw new Error('Server not reachable');

    // Test token auth
    if (token) {
      const meRes = await fetch(`${serverUrl}/api/auth/me`, {
        headers: { 'Authorization': `Bearer ${token}`, ...cfHeaders }
      });
      if (!meRes.ok) throw new Error('Invalid token');
      const me = await meRes.json();
      settingsStatus.textContent = t('connectedAs', { username: me.username });
      settingsStatus.className = 'settings-status ok';
    } else {
      settingsStatus.textContent = t('serverReachableNoToken');
      settingsStatus.className = 'settings-status ok';
    }
  } catch (e) {
    const msg = e.message === 'Failed to fetch'
      ? t('cannotReachServer')
      : (e.message || t('connectionFailed'));
    settingsStatus.textContent = msg;
    settingsStatus.className = 'settings-status err';
    console.error('Sync test error:', e);
  } finally {
    testConnBtn.disabled = false;
  }
});

// Load saved settings
async function loadSettings() {
  const settings = await getSettings();
  serverUrlInput.value = settings.serverUrl || '';
  syncTokenInput.value = settings.token || '';
  cfClientIdInput.value = settings.cfAccessClientId || '';
  cfClientSecretInput.value = settings.cfAccessClientSecret || '';
}

// --- Auto-sync helper ---
function triggerAutoSync() {
  // Fire-and-forget: sync in background after local operations
  isSyncConfigured().then(configured => {
    if (configured) {
      detectWorkspaceWindows().then(wins => performSync(wins)).then(result => {
        if (!result.error) renderList();
      }).catch(() => {});
    }
  });
}

// --- Sync ---
const syncBar = document.getElementById('sync-bar');
const syncBtn = document.getElementById('sync-btn');
const syncStatus = document.getElementById('sync-status');
const clockOffsetEl = document.getElementById('clock-offset');

function updateClockOffsetDisplay() {
  const { offset, calibrated } = getClockOffset();
  if (!calibrated) {
    clockOffsetEl.textContent = '';
    clockOffsetEl.title = '';
    return;
  }
  const sec = (offset / 1000).toFixed(1);
  const sign = offset >= 0 ? '+' : '';
  clockOffsetEl.textContent = `${sign}${sec}s`;
  clockOffsetEl.title = `Clock offset: client ${offset >= 0 ? 'behind' : 'ahead of'} server by ${Math.abs(sec)}s`;
  // Color hint: green if <1s, yellow if 1-5s, red if >5s
  const abs = Math.abs(offset);
  if (abs < 1000) clockOffsetEl.style.color = '';
  else if (abs < 5000) clockOffsetEl.style.color = 'var(--ws-orange, #ca5010)';
  else clockOffsetEl.style.color = 'var(--ws-red, #d13438)';
}

async function updateSyncBar() {
  const configured = await isSyncConfigured();
  syncBar.style.display = configured ? 'flex' : 'none';
}

async function doSync() {
  syncBtn.disabled = true;
  syncStatus.innerHTML = `<span class="sync-spinner"></span> ${t('syncing')}`;
  syncStatus.className = 'sync-status';

  const openWindows = await detectWorkspaceWindows();
  console.log('[Tabsy] Manual sync: detected workspace windows:', openWindows);
  const result = await performSync(openWindows);
  console.log('[Tabsy] Manual sync result:', result);

  if (result.error) {
    syncStatus.textContent = result.error;
    syncStatus.className = 'sync-status err';
  } else {
    const parts = [];
    if (result.pulled > 0) parts.push(t('pulled', { n: result.pulled }));
    if (result.pushed > 0) parts.push(t('pushed', { n: result.pushed }));
    if (result.conflicts > 0) parts.push(t('conflicts', { n: result.conflicts }));
    syncStatus.textContent = parts.length > 0 ? parts.join(', ') : t('upToDate');
    syncStatus.className = 'sync-status ok';
    await renderList();
    renderConflictBanner();
  }

  updateClockOffsetDisplay();
  syncBtn.disabled = false;
}

syncBtn.addEventListener('click', doSync);

// Auto-sync toggle
const autoSyncCheckbox = document.getElementById('auto-sync-checkbox');
getAutoSync().then(enabled => { autoSyncCheckbox.checked = enabled; });
autoSyncCheckbox.addEventListener('change', () => {
  setAutoSync(autoSyncCheckbox.checked);
});

// Update sync bar after save settings
saveSettingsBtn.addEventListener('click', async () => {
  // Wait for settings to be saved, then update sync bar visibility
  setTimeout(async () => {
    await updateSyncBar();
  }, 100);
});

// --- Flow execution ---

const flowLogPanel = document.getElementById('flow-log-panel');
const flowLogName = document.getElementById('flow-log-name');
const flowLogState = document.getElementById('flow-log-state');
const flowLogBody = document.getElementById('flow-log-body');
const flowLogClose = document.getElementById('flow-log-close');

let activeRunner = null;

flowLogClose.addEventListener('click', () => {
  flowLogPanel.classList.remove('open');
  if (activeRunner && activeRunner.state === RunState.RUNNING) {
    activeRunner.stop();
  }
  activeRunner = null;
});

function showFlowLog(flowName) {
  flowLogName.textContent = flowName;
  flowLogBody.innerHTML = '';
  flowLogState.textContent = '';
  flowLogState.className = 'flow-state';
  flowLogPanel.classList.add('open');
}

function appendFlowLog(entry) {
  const div = document.createElement('div');
  div.className = 'flow-log-entry';
  const time = new Date(entry.time).toLocaleTimeString(undefined, { timeZone: _currentTz });
  div.innerHTML = `<span class="flow-log-time">${time}</span> <span class="flow-log-msg">${escapeHtml(entry.message)}</span>`;
  flowLogBody.appendChild(div);
  flowLogBody.scrollTop = flowLogBody.scrollHeight;
}

function showFlowResult(result) {
  flowLogState.textContent = result.state;
  flowLogState.className = `flow-state ${result.state === RunState.DONE ? 'done' : result.state === RunState.ERROR ? 'error' : ''}`;

  if (result.error) {
    const div = document.createElement('div');
    div.className = 'flow-log-entry';
    div.innerHTML = `<span class="flow-log-err">Error: ${escapeHtml(result.error)}</span>`;
    flowLogBody.appendChild(div);
  }

  // Show final variables
  const vars = Object.entries(result.variables).filter(([k]) => !k.startsWith('_'));
  if (vars.length > 0) {
    const div = document.createElement('div');
    div.className = 'flow-log-vars';
    div.innerHTML = vars.map(([k, v]) => `${escapeHtml(k)}: ${escapeHtml(String(v))}`).join('<br>');
    flowLogBody.appendChild(div);
  }
  flowLogBody.scrollTop = flowLogBody.scrollHeight;
}

async function runFlowOnActiveTab(workspaceId, flowId) {
  const flow = await (async () => {
    const wsFlows = await getFlows(workspaceId);
    return wsFlows.find(f => f.id === flowId);
  })();
  if (!flow) return;

  // Stop existing runner
  if (activeRunner && activeRunner.state === RunState.RUNNING) {
    activeRunner.stop();
  }

  // Get active tab
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;

  showFlowLog(flow.name);
  flowLogState.textContent = 'running';
  flowLogState.className = 'flow-state running';

  const runner = new FlowRunner(flow, tab.id);
  activeRunner = runner;

  runner.onLog = appendFlowLog;
  runner.onBlockStart = (block, i) => {
    const def = BLOCK_TYPES[block.type];
    appendFlowLog({ time: new Date().toISOString(), message: `▶ ${def?.label || block.type}` });
  };

  const result = await runner.run();
  showFlowResult(result);
}

// Render flow chips for a workspace card (compact for non-current workspaces)
function renderFlowChips(workspaceId, flows) {
  if (!flows || flows.length === 0) {
    return `
      <div class="ws-flow-section">
        <div class="ws-flow-header">
          <span>${t('flows')}</span>
          <button class="btn btn-sm btn-secondary" data-add-flow="${workspaceId}">${t('newFlow')}</button>
        </div>
      </div>`;
  }

  // Compact summary: show flow names as chips, minimal actions
  const chips = flows.map(f => {
    const urlMatched = f.enabled && f.trigger !== 'manual' && f.match && _activeTabUrl && matchUrlPattern(f.match, _activeTabUrl);
    return `
    <span class="flow-chip ${f.enabled ? '' : 'disabled'} ${urlMatched ? 'url-matched' : ''}">
      ${urlMatched ? '<span class="flow-match-dot" title="Matches current tab">&#9889;</span>' : ''}
      <span class="flow-edit" data-edit-flow="${f.id}" data-ws="${workspaceId}" title="${t('edit')}">${escapeHtml(f.name)}</span>
      <span class="flow-run" data-run-flow="${f.id}" data-ws="${workspaceId}" title="${t('run')}">&#9654;</span>
      <span class="flow-dup" data-dup-flow="${f.id}" data-ws="${workspaceId}" title="${t('duplicate')}">&#10063;</span>
    </span>`;
  }).join('');

  return `
    <div class="ws-flow-section">
      <div class="ws-flow-header">
        <span>${t('flows')} (${flows.length})</span>
        <button class="btn btn-sm btn-secondary" data-add-flow="${workspaceId}">${t('newFlow')}</button>
      </div>
      <div>${chips}</div>
    </div>`;
}

async function startRenameFlow(el, workspaceId, flowId) {
  const chip = el.closest('.flow-chip');
  const oldName = el.textContent;
  const input = document.createElement('input');
  input.type = 'text';
  input.value = oldName;
  input.style.cssText = 'width:80px;font-size:11px;padding:0 4px;border:1px solid var(--primary);border-radius:3px;outline:none;';
  el.replaceWith(input);
  input.focus();
  input.select();

  const finish = async () => {
    const newName = input.value.trim();
    if (newName && newName !== oldName) {
      const flow = await getFlowById(workspaceId, flowId);
      if (flow) {
        flow.name = newName;
        await saveFlow(workspaceId, flow);
      }
    }
    await renderList();
  };

  input.addEventListener('blur', finish);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); input.blur(); }
    if (e.key === 'Escape') { input.value = oldName; input.blur(); }
  });
}

function openFlowEditor(wsId, flowId) {
  viewMain.style.display = 'none';
  viewFlow.style.display = '';
  mountFlowEditor(wsId, flowId, () => {
    // Back button callback
    unmountFlowEditor();
    viewFlow.style.display = 'none';
    viewMain.style.display = '';
    renderList();
    detectCurrentWorkspace();
  });
}

async function addNewFlow(workspaceId) {
  const flow = createFlow();
  await saveFlow(workspaceId, flow);
  openFlowEditor(workspaceId, flow.id);
}

async function duplicateFlow(workspaceId, flowId) {
  const src = await getFlowById(workspaceId, flowId);
  if (!src) return;
  // Deep clone to avoid sharing nested blocks/variables with the original
  const copy = structuredClone(src);
  copy.id = crypto.randomUUID();
  copy.name = `${src.name} (copy)`;
  // New flows start untrusted — user must re-approve dangerous blocks
  delete copy.codeTrusted;
  await saveFlow(workspaceId, copy);
}

// --- i18n: apply translations to static HTML elements ---
function applyI18n() {
  document.querySelectorAll('[data-i18n]').forEach(el => {
    el.textContent = t(el.dataset.i18n);
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    el.placeholder = t(el.dataset.i18nPlaceholder);
  });
  document.querySelectorAll('[data-i18n-title]').forEach(el => {
    el.title = t(el.dataset.i18nTitle);
  });
}

// --- Language selector ---
const langSelect = document.getElementById('lang-select');
langSelect.value = getLocale();
langSelect.addEventListener('change', async () => {
  await setLocale(langSelect.value);
  applyI18n();
  await detectCurrentWorkspace();
  await renderList();
  renderConflictBanner();
});

// --- Timezone selector ---
const tzSelect = document.getElementById('tz-select');
let _currentTz = getDetectedTimezone();

async function initTimezone() {
  _currentTz = await getTimezone();
  // Populate timezone options
  const detected = getDetectedTimezone();
  let zones;
  try {
    zones = Intl.supportedValuesOf('timeZone');
  } catch {
    // Fallback for older browsers
    zones = [detected];
  }
  // Add auto-detect option at top
  const autoLabel = `Auto (${detected})`;
  tzSelect.innerHTML = `<option value="">${autoLabel}</option>` +
    zones.map(z => `<option value="${z}" ${z === _currentTz && _currentTz !== detected ? 'selected' : ''}>${z}</option>`).join('');

  // If user has a saved timezone, select it; otherwise keep "Auto"
  const saved = (await chrome.storage.local.get('tabsyTimezone')).tabsyTimezone;
  if (saved) {
    tzSelect.value = saved;
  } else {
    tzSelect.value = '';
  }
}

tzSelect.addEventListener('change', async () => {
  await setTimezone(tzSelect.value);
  _currentTz = tzSelect.value || getDetectedTimezone();
  await detectCurrentWorkspace();
  await renderList();
});

// --- Init (progressive: show content fast, defer heavy work) ---
await initLocale();
langSelect.value = getLocale();
await initTimezone();
applyI18n();
initColorPicker();

// Phase 1: detect current workspace first (renderList depends on it)
Promise.all([detectCurrentWorkspace(), refreshActiveTabUrl()]).then(() => renderList()).then(() => {
  // Phase 2: non-critical UI + sync (deferred)
  renderConflictBanner();
  loadSettings();
  updateSyncBar();
  isSyncConfigured().then(configured => {
    if (configured) doSync();
  });
});

// Re-render when background auto-sync updates workspaces
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.workspaces) {
    detectCurrentWorkspace().then(() => renderList());
    renderConflictBanner();
  }
});

// Re-render flow match badges when active tab changes
chrome.tabs.onActivated.addListener(async () => {
  await refreshActiveTabUrl();
  renderList();
  if (currentWorkspaceData) {
    const ws = await getById(currentWorkspaceData.id);
    if (ws) { renderCurrentWsFlows(ws); renderCurrentWsNotes(ws); }
  }
});
chrome.tabs.onUpdated.addListener(async (_tabId, changeInfo) => {
  if (!changeInfo.url && !changeInfo.title) return;
  console.log('[onUpdated] tabId:', _tabId, 'change:', changeInfo, 'mapping has:', _chromeTabToWsTab.has(_tabId));
  await refreshActiveTabUrl();
  renderList();
  if (currentWorkspaceData) {
    const ws = await getById(currentWorkspaceData.id);
    if (ws) { renderCurrentWsFlows(ws); renderCurrentWsNotes(ws); }
  }
});
chrome.tabs.onRemoved.addListener(async (tabId) => {
  _chromeTabToWsTab.delete(tabId);
  if (currentWorkspaceData) {
    const ws = await getById(currentWorkspaceData.id);
    if (ws) renderCurrentWsNotes(ws);
  }
});
